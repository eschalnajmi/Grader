
void playGame( Game *game, int gridsize, int winlen );

void showGame( Game *game, int boardSize );

int isInt(char move);

int makeMove( Game *game, char symbol );
